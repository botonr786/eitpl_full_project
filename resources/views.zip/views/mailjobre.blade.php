<p>Hello <b>{{ $name }}</b>,</p>

 <p>You are {{ $status }} for  {{ $pos }} against job code {{ $job_code }}  on {{ date('d/m/Y',strtotime($date)) }}.</p>
  <p>Thank you  for applying.</p>
  
   
  <p>Thanks</p>