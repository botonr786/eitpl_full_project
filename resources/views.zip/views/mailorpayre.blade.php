<p>Hello <b>{{ $f_name }}  {{ $l_name }}</b>,</p>

 <p>Your payment  amount £ {{$amount}} is successfully received  against bill number {{$bill}} . </p>
 <p>Download you invoice from the link: {{$invoice_path}}</p>

  <p>  Thanks & Regards</p>
   <p>  Workpermitcloud limited</p>
