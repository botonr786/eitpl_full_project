<footer class="footer">
				<div class="container-fluid">

					<div class="copyright ml-auto">
						&copy <?php echo date('Y'); ?> WorkPermitCloud | All Right Reserved
					</div>
				</div>
			</footer>