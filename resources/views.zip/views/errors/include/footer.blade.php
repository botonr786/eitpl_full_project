<footer class="footer">
				<div class="container-fluid">
					
					<div class="copyright ml-auto">
						&copy 2021 WorkPermitCloud | All Right Reserved
					</div>				
				</div>
			</footer>