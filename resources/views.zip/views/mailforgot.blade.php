<p>Hello <b>{{ $name }}  </b>,</p>

 
   <p> Your Password is  {{ $pass}} for login. </p>
  
  
     <p>  Login Link :<a href="http://workpermitcloud.co.uk/hrms/">http://workpermitcloud.co.uk/hrms/</a>.</p>
  <p>  Thanks</p>