


 {!!html_entity_decode($msg)!!}
 
   <p>  Thanks & Regards</p>
 
  <p> WORKPERMITCLOUD LIMITED</p>