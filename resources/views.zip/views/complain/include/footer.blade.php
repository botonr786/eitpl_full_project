<footer class="footer">
				<div class="container-fluid">
					
					<div class="copyright ml-auto">
						&copy 2021 HRMS | All Right Reserved
					</div>				
				</div>
			</footer>