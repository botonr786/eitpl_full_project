<p>Hello <b>{{ $name }}</b>,</p>

 <p>You are qualified to {{ $status }} for the position of {{ $pos }} against job code {{ $job_code }} on {{ date('d/m/Y',strtotime($date)) }}.</p>
  <p>Thank you for applying.</p>
  <p>For further query we will contact to you shortly.</p>
   
  <p>Thanks</p>