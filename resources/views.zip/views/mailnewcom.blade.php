<p>Hello ,</p>

 <p>New Complaint has been come. </p>
 <p>Here is the details:</p>
 <p>Complain Id: {{$ind}}</p>
 <p>Project Name: {{$p_name}}</p>
 <p>Category : {{$cat_name}}  {{$others}}</p>
 <p>Company Name : {{$com_name}}  </p>
  <p>Description: {{$descrption}}</p>
  <p>  Thanks & Regards</p>
   <p>  Workpermitcloud limited</p>