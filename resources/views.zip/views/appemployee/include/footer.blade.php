<footer class="footer">
				<div class="container-fluid">
					
					<div class="copyright ml-auto">
						&copy 2020 HRMS | All Right Reserved
					</div>				
				</div>
			</footer>