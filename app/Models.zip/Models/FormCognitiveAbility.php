<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
// use Illuminate\Database\Eloquent\SoftDeletes;

class FormCognitiveAbility extends Model
{
    // use SoftDeletes;

    protected $fillable = ['interview_form_id'];

}
